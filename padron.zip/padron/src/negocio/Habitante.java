package negocio;

public class Equipo{
	private String liga, pais, region;

	public Equipo(String liga, String pais, String region){
		this.liga = liga;
		this.pais = pais;
		this.region = region;
	}

	@Override
	public String toString(){
		return getLiga() + "," + getPais() + "," + getRegion(); 
	}

	public String getLiga(){
		return liga;
	}

	public String getPais(){
		return pais;
	}

	public String getRegion(){
		return region;
	}
}
